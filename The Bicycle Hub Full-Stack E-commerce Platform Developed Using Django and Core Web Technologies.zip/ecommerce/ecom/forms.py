from django import forms
from django.contrib.auth.models import User
from . import models
from django import forms
from django.contrib.auth.forms import UserCreationForm



#signup
class CustomerSignupForm(UserCreationForm):
    class Meta:

        model = User
        fields = ['first_name', 'last_name', 'username','password1','password2']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Username'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter First Name'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Last Name'}),
            'password1': forms.PasswordInput(attrs={'placeholder': 'Password'}),
            'password2': forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}),
        }
    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Passwords do not match.")
        
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        if self.cleaned_data.get("password1"):
            user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user
    

    
#signup 
class CustomerForm(forms.ModelForm):
    class Meta:
        model = models.Customer
        fields = ['address', 'mobile','profile_pic']

    def save(self, commit=True):
        customer = super().save(commit=False)
        
        # Automatically set the default profile picture if not provided
        if not customer.profile_pic:
            customer.profile_pic = 'profile_pic/default/default.jpg'
        
        if commit:
            customer.save()
        return customer




#edit profile details
class CustomerEditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Username'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter First Name'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Last Name'}),
        }
    def save(self, commit=True):
        user = super().save(commit=False)
        # Only set the password if it's not in edit mode (i.e., for signup)
       
        if commit:
            user.save()
        return user

#for edit profile details
class CustomereditForm(forms.ModelForm):
    class Meta:
        model = models.Customer
        fields = ['address', 'mobile']

    def save(self, commit=True):
        customer = super().save(commit=False)
        
        # Automatically set the default profile picture if not provided
        
        if commit:
            customer.save()
        return customer
    

#for products
class ProductForm(forms.ModelForm):
    class Meta:
        model=models.Product
        fields=['name','price','description','product_image']

#address of shipment
class AddressForm(forms.Form):
    Email = forms.EmailField()
    Mobile= forms.IntegerField()
    Address = forms.CharField(max_length=500)


#for updating status of order
class OrderForm(forms.ModelForm):
    class Meta:
        model=models.Orders
        fields=['status']

#for edit profile pic
class CustomerProfileForm(forms.ModelForm):
    class Meta:
        model = models.Customer
        fields = ['profile_pic']  # Add other fields if needed, e.g., 'first_name', 'last_name', etc.