from django.db import models
from django.contrib.auth.models import User
# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class Customer(models.Model):
    id = models.BigAutoField(primary_key=True)  # Explicit primary key
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=False, blank=False)
    first_name = models.CharField(max_length=30, default='', blank=True)
    last_name = models.CharField(max_length=30, default='', blank=True)
    profile_pic = models.ImageField(default='profile_pic/default/default.jpg', upload_to='profile_pic/')  # Always uses default
    address = models.CharField(max_length=40, default='', blank=True)
    mobile = models.CharField(max_length=20, default='', blank=True)
    

    def save(self, *args, **kwargs):
        
        self.first_name = self.user.first_name
        self.last_name = self.user.last_name
        if not self.profile_pic:
            self.profile_pic = 'profile_pic/default/default.jpg'
        
        super().save(*args, **kwargs)

    @property
    def get_name(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def get_id(self):
        return self.user.id

    def __str__(self):
        return f"{self.user.username} - {self.first_name} {self.last_name} - {self.mobile} - {self.address}"



class Product(models.Model):
    name=models.CharField(max_length=40)
    product_image= models.ImageField(upload_to='product_image/',null=True,blank=True)
    price = models.PositiveIntegerField()
    description=models.CharField(max_length=40)
    def __str__(self):
        return self.name


class Orders(models.Model):
    STATUS =(
        ('Pending','Pending'),
        ('Order Confirmed','Order Confirmed'),
        ('Out for Delivery','Out for Delivery'),
        ('Delivered','Delivered'),
    )
    customer=models.ForeignKey('Customer', on_delete=models.CASCADE,null=True)
    product=models.ForeignKey('Product',on_delete=models.CASCADE,null=True)
    email = models.CharField(max_length=50,null=True)
    address = models.CharField(max_length=500,null=True)
    mobile = models.CharField(max_length=20,null=True)
    order_date= models.DateField(auto_now_add=True,null=True)
    status=models.CharField(max_length=50,null=True,choices=STATUS)

    def __str__(self):
        return f"{self.product}"

