from django.shortcuts import render,redirect,reverse
from . import forms, models
from django.http import HttpResponseRedirect,HttpResponse
from django.core.mail import send_mail
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib import messages
from django.conf import settings
from django.contrib.auth.models import User
from django.http import Http404
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages

from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth import update_session_auth_hash
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
#from .models import UserProfile
#from .forms import EditProfilePhotoForm
from django.contrib.auth.decorators import login_required
from .forms import CustomerSignupForm,CustomerForm,CustomerEditProfileForm,CustomereditForm
from .forms import CustomerProfileForm

#from .forms import Customer



def home_view(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'ecom/index.html',{'products':products,'product_count_in_cart':product_count_in_cart})
    

#for showing login button for admin
#for showing login button for admin
def adminclick_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return HttpResponseRedirect('adminlogin')

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

def customer_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        
        # Try to authenticate user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('customer-home')  # or any redirect path
        else:
            # Check if the username exists in the database
            if not User.objects.filter(username=username).exists():
                error_message = "User does not exist."
            else:
                # If user exists, but password is wrong
                error_message = "Incorrect password."
            
            return render(request, 'customerlogin.html', {'error_message': error_message})  # Pass the error to the template

    return render(request, 'customerlogin.html')


def customer_signup_view(request):
    # Initialize forms
    userForm = forms.CustomerSignupForm()
    customerForm = forms.CustomerForm()

    # Prepare context to render the forms
    context = {'userForm': userForm, 'customerForm': customerForm}

    if request.method == 'POST':
        userForm = forms.CustomerSignupForm(request.POST)
        customerForm = forms.CustomerForm(request.POST, request.FILES)

        # First, check if both forms are valid
        if userForm.is_valid() and customerForm.is_valid():
            # Check if the username already exists
            username = userForm.cleaned_data.get('username')
            if User.objects.filter(username=username).exists():
                messages.error(request, "This username is already taken. Please choose another one.")
                return render(request, 'ecom/customersignup.html', context)

            # Check if the passwords match
            password1 = userForm.cleaned_data.get('password1')
            password2 = userForm.cleaned_data.get('password2')
            if password1 != password2:
                messages.error(request, "Passwords do not match. Please try again.")
                return render(request, 'ecom/customersignup.html', context)

            # Save the user instance
            user = userForm.save()
            user.set_password(password1)  # Hash the password
            user.save()

            # Save the customer instance
            customer = customerForm.save(commit=False)
            customer.user = user
            customer.save()

            # Add the user to the "CUSTOMER" group
            my_customer_group, created = Group.objects.get_or_create(name='CUSTOMER')
            my_customer_group.user_set.add(user)

            # Redirect to login page after successful signup
            messages.success(request, "Your account has been created successfully!")
            return HttpResponseRedirect('customerlogin')

        else:
            # If the form is not valid, return errors to the user
            messages.error(request, "There were some errors with your form. Please correct them and try again.")

    return render(request, 'ecom/customersignup.html', context)

#for checking user iscustomer
def is_customer(user):
    return user.groups.filter(name='CUSTOMER').exists()



#AFTER ENTERING CREDENTIALS WE CHECK WHETHER USERNAME AND PASSWORD IS OF ADMIN,CUSTOMER
def afterlogin_view(request):
    if is_customer(request.user):
        return redirect('customer-home')
    else:
        return redirect('admin-dashboard')


#ADMIN RELATED VIEWS START 

@login_required(login_url='adminlogin')
def admin_dashboard_view(request):
    # for cards on dashboard
    customercount=models.Customer.objects.all().count()
    productcount=models.Product.objects.all().count()
    ordercount=models.Orders.objects.all().count()

    # for recent order tables
    orders=models.Orders.objects.all()
    ordered_products=[]
    ordered_bys=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_by=models.Customer.objects.all().filter(id = order.customer.id)
        ordered_products.append(ordered_product)
        ordered_bys.append(ordered_by)

    mydict={
    'customercount':customercount,
    'productcount':productcount,
    'ordercount':ordercount,
    'data':zip(ordered_products,ordered_bys,orders),
    }
    return render(request,'ecom/admin_dashboard.html',context=mydict)


# admin view customer table
@login_required(login_url='adminlogin')
def view_customer_view(request):
    customers=models.Customer.objects.all()
    return render(request,'ecom/view_customer.html',{'customers':customers})

# admin delete customer

@login_required(login_url='adminlogin')
def delete_customer_view(request, pk):
    try:
        customer = models.Customer.objects.get(id=pk)
        user = models.User.objects.get(id=customer.user_id)
    except (models.Customer.DoesNotExist, models.User.DoesNotExist):
        raise Http404("Customer not found")

    # Prevent deletion of an admin user
    if user.is_staff:
        messages.error(request, "Cannot delete an admin account.")
        return redirect('view-customer')

    if request.method == "POST":
        user.delete()  # Deleting the user associated with the customer
        customer.delete()  # Deleting the customer instance
        messages.success(request, "Customer deleted successfully.")
        return redirect('view-customer')  # Redirect to the customer list view after deletion

    # If it's a GET request, show confirmation page
    return render(request, 'ecom/confirm_delete_customer.html', {'customer': customer})




@login_required(login_url='adminlogin')
def delete_product_view(request, pk):
    
    product = models.Product.objects.get(id=pk)
    

    # If the request method is POST, delete the product
    if request.method == 'POST':
            
        # Check if the user confirmed the delete
            product.delete()  # Delete the product
            return redirect('admin-products')  # Redirect after deletion

    # Render the confirmation page on GET request
    return render(request, 'ecom/product_delete_confirmation.html', {'product': product})






@login_required(login_url='adminlogin')
def update_customer_view(request,pk):
    customer=models.Customer.objects.get(id=pk)
    user=models.User.objects.get(id=customer.user_id)
    userForm=forms.CustomerEditProfileForm(instance=user)
    customerForm=forms.CustomereditForm(request.FILES,instance=customer)
    mydict = {
        'userForm': userForm,
        'customerForm': customerForm,
        'user': user,
        'customer': customer,
        'mobile': customer.mobile,
        'address': customer.address,
    }
    
    if request.method == 'POST':
        # Reinitialize forms with POST data and files (for profile picture)
        userForm = forms.CustomerEditProfileForm(request.POST, instance=user)
        customerForm = forms.CustomereditForm(request.POST, request.FILES, instance=customer)

        if userForm.is_valid() and customerForm.is_valid():
            # Save the user form (this will correctly save the username and other user fields)
            userForm.save()

            # Save the customer form (this will handle the profile fields and picture)
            customerForm.save()

            return redirect('view-customer')
    return render(request,'ecom/admin_update_customer.html',context=mydict)

    

    

@login_required
def change_password(request):
    user = request.user  # Get the currently logged-in user

    if request.method == 'POST':
        form = SetPasswordForm(user, request.POST)  # Bind the form to the current user
        if form.is_valid():
            form.save()  # This hashes and updates the password in the database
            messages.success(request, "Your password has been successfully updated.")
            return redirect('customerlogin')  # Redirect to login or another page
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = SetPasswordForm(user)

    return render(request, 'change_password.html', {'form': form})

#code for deleting the user/custmer
@login_required
def delete_account_view(request):
    if request.method == "POST":
        user = request.user
        user.delete()
        messages.success(request, "Your account has been deleted successfully.")
        return redirect('home')  # Redirect to the home page or any other page
    return render(request, 'ecom/delete_account.html')

# admin view the product
@login_required(login_url='adminlogin')
def admin_products_view(request):
    products=models.Product.objects.all()
    return render(request,'ecom/admin_products.html',{'products':products})


# admin add product by clicking on floating button
@login_required(login_url='adminlogin')
def admin_add_product_view(request):
    productForm=forms.ProductForm()
    if request.method=='POST':
        productForm=forms.ProductForm(request.POST, request.FILES)
        if productForm.is_valid():
            productForm.save()
        return HttpResponseRedirect('admin-products')
    return render(request,'ecom/admin_add_products.html',{'productForm':productForm})


@login_required(login_url='adminlogin')
def delete_product_view(request,pk):
    product=models.Product.objects.get(id=pk)
    product.delete()
    return redirect('admin-products')


@login_required(login_url='adminlogin')
def update_product_view(request,pk):
    product=models.Product.objects.get(id=pk)
    productForm=forms.ProductForm(instance=product)
    if request.method=='POST':
        productForm=forms.ProductForm(request.POST,request.FILES,instance=product)
        if productForm.is_valid():
            productForm.save()
            return redirect('admin-products')
    return render(request,'ecom/admin_update_product.html',{'productForm':productForm})


@login_required(login_url='adminlogin')
def admin_view_booking_view(request):
    orders=models.Orders.objects.all()
    ordered_products=[]
    ordered_bys=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_by=models.Customer.objects.all().filter(id = order.customer.id)
        ordered_products.append(ordered_product)
        ordered_bys.append(ordered_by)
    return render(request,'ecom/admin_view_booking.html',{'data':zip(ordered_products,ordered_bys,orders)})


@login_required(login_url='adminlogin')
def delete_order_view(request,pk):
    order=models.Orders.objects.get(id=pk)
    order.delete()
    return redirect('admin-view-booking')

# for changing status of order (pending,delivered...)
@login_required(login_url='adminlogin')
def update_order_view(request,pk):
    order=models.Orders.objects.get(id=pk)
    orderForm=forms.OrderForm(instance=order)
    if request.method=='POST':
        orderForm=forms.OrderForm(request.POST,instance=order)
        if orderForm.is_valid():
            orderForm.save()
            return redirect('admin-view-booking')
    return render(request,'ecom/update_order.html',{'orderForm':orderForm})





# PUBLIC CUSTOMER RELATED VIEWS START 

def search_view(request):
    # whatever user write in search box we get in query
    query = request.GET['query']
    products=models.Product.objects.all().filter(name__icontains=query)
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0

    # word variable will be shown in html when user click on search button
    word="Searched Result :"

    if request.user.is_authenticated:
        return render(request,'ecom/customer_home.html',{'products':products,'word':word,'product_count_in_cart':product_count_in_cart})
    return render(request,'ecom/index.html',{'products':products,'word':word,'product_count_in_cart':product_count_in_cart})


# any one can add product to cart, no need of signin
def add_to_cart_view(request, pk):
    products = models.Product.objects.all()

    # For cart counter, fetching product IDs added by the customer from cookies
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter = product_ids.split('|')
        product_count_in_cart = len(counter)  # Count all products, even duplicates
    else:
        product_count_in_cart = 0  # No products in cart

    # Update cookies with the new product ID
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        product_ids = f"{product_ids}|{pk}"  # Append new product ID to existing list
        response = render(request, 'ecom/index.html', {'products': products, 'product_count_in_cart': product_count_in_cart})
        response.set_cookie('product_ids', product_ids)
    else:
        response = render(request, 'ecom/index.html', {'products': products, 'product_count_in_cart': product_count_in_cart})
        response.set_cookie('product_ids', pk)  # First product added to cart

    return response




# for checkout of cart
# for checkout of cart
from django.shortcuts import render
from . import models

def cart_view(request):
    # Fetch cart items and calculate the quantity
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter = product_ids.split('|')
        product_count_in_cart = len((counter))  # Get unique product count
    else:
        product_count_in_cart = 0

    # Fetch product details based on product ids stored in cookies
    products = None
    total = 0
    cart_items = []  # List to store product and quantity tuples
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids != "":
            product_id_in_cart = product_ids.split('|')
            products = models.Product.objects.all().filter(id__in=product_id_in_cart)

            # Calculate the total price of the cart
            for p in products:
                quantity = product_id_in_cart.count(str(p.id))
                cart_items.append((p, quantity))  # Store product and quantity in the list
                total += p.price * quantity  # Multiply price by quantity
                

            
    return render(request, 'ecom/cart.html', {'cart_items': cart_items, 'total': total, 'product_count_in_cart': product_count_in_cart})




def reduce_quantity_view(request, pk):
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        product_id_list = product_ids.split('|')

        # Check if the product exists in the cart
        if str(pk) in product_id_list:
            count = product_id_list.count(str(pk))

            # If the count is greater than 1, reduce by 1
            if count > 1:
                product_id_list.remove(str(pk))  # Remove one occurrence of the product

            # If the count is 1 (quantity becomes 0), remove the product completely
            elif count == 1:
                product_id_list.remove(str(pk))

        # If the list is empty after removing the product, clear the cookie
        if not product_id_list:
            response = redirect('cart')  # Redirect to the cart page
            response.delete_cookie('product_ids')  # Clear the cookie as the cart is empty
        else:
            response = redirect('cart')  # Redirect to the cart page
            response.set_cookie('product_ids', '|'.join(product_id_list))  # Update the cookie with the new list of products

        return response
    else:
        # If there is no 'product_ids' cookie (cart is empty), just redirect
        return redirect('cart')


def increase_quantity_view(request, pk):
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        product_id_list = product_ids.split('|')

        # Add one more of the product to the cart
        product_id_list.append(str(pk))

        # Update the cookie and reload the cart page
        response = redirect('cart')  # Redirect to cart page
        response.set_cookie('product_ids', '|'.join(product_id_list))
        return response




def remove_from_cart_view(request, pk):
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        product_id_list = product_ids.split('|')

        # Remove all occurrences of the product from the list
        product_id_list = [id for id in product_id_list if id != str(pk)]

        # If the cart is empty after removal, clear the cookie
        if len(product_id_list) == 0:
            response = redirect('cart')  # Redirect to the cart page
            response.delete_cookie('product_ids')  # Delete the cart cookie
            return response

        # Update the cart in cookies and redirect
        response = redirect('cart')  # Redirect to the cart page
        response.set_cookie('product_ids', '|'.join(product_id_list))  # Update the cookie with the modified list
        return response
    return HttpResponse("Product not found in cart", status=404)


# CUSTOMER RELATED VIEWS START 


@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def customer_home_view(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len((counter))
    else:
        product_count_in_cart=0
    return render(request,'ecom/customer_home.html',{'products':products,'product_count_in_cart':product_count_in_cart})



# shipment address before placing order
@login_required(login_url='customerlogin')
def customer_address_view(request):
    # this is for checking whether product is present in cart or not
    # if there is no product in cart we will not show address form
    product_in_cart=False
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids != "":
            product_in_cart=True
    #for counter in cart
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0

    addressForm = forms.AddressForm()
    if request.method == 'POST':
        addressForm = forms.AddressForm(request.POST)
        if addressForm.is_valid():
            # here we are taking address, email, mobile at time of order placement
            # we are not taking it from customer account table because
            # these thing can be changes
            email = addressForm.cleaned_data['Email']
            mobile=addressForm.cleaned_data['Mobile']
            address = addressForm.cleaned_data['Address']
            #for showing total price on payment page.....accessing id from cookies then fetching  price of product from db
            total=0
            if 'product_ids' in request.COOKIES:
                product_ids = request.COOKIES['product_ids']
                if product_ids != "":
                    product_id_in_cart=product_ids.split('|')
                    products=models.Product.objects.all().filter(id__in = product_id_in_cart)
                    for p in products:
                        total=total+p.price

            response = render(request, 'ecom/payment.html',{'total':total})
            response.set_cookie('email',email)
            response.set_cookie('mobile',mobile)
            response.set_cookie('address',address)
            return response
    return render(request,'ecom/customer_address.html',{'addressForm':addressForm,'product_in_cart':product_in_cart,'product_count_in_cart':product_count_in_cart})




# here we are just directing to this view...actually we have to check whther payment is successful or not
#then only this view should be accessed
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from . import models

def payment_error_view(request):
    return render(request, 'ecom/payment_error.html')

@login_required(login_url='customerlogin')
def payment_success_view(request):
    customer = models.Customer.objects.get(user_id=request.user.id)
    products = None
    email = None
    mobile = None
    address = None

    # Fetch product IDs from cookies
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids:
            product_id_in_cart = product_ids.split('|')
            products = models.Product.objects.filter(id__in=product_id_in_cart)

    # Fetch customer details from cookies
    if 'email' in request.COOKIES:
        email = request.COOKIES['email']
    if 'mobile' in request.COOKIES:
        mobile = request.COOKIES['mobile']
    if 'address' in request.COOKIES:
        address = request.COOKIES['address']

    # Place orders (only if products is not None)
    if products:
        for product in products:
            models.Orders.objects.get_or_create(
                customer=customer,
                product=product,
                status='Pending',
                email=email,
                mobile=mobile,
                address=address
            )

    # Delete cookies after placing the order
    response = render(request, 'ecom/payment_success.html')
    response.delete_cookie('product_ids')
    response.delete_cookie('email')
    response.delete_cookie('mobile')
    response.delete_cookie('address')
    return response


@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def my_order_view(request):
    
    customer=models.Customer.objects.get(user_id=request.user.id)
    orders=models.Orders.objects.all().filter(customer_id = customer)
    ordered_products=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_products.append(ordered_product)

    return render(request,'ecom/my_order.html',{'data':zip(ordered_products,orders)})
 




@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def my_profile_view(request):
    customer = models.Customer.objects.get(user_id=request.user.id)
    print(customer.profile_pic.url)  # This will print the path in the console
    print(f"User: {request.user}")  # Check if user data is being passed correctly
      # Check if the email exists
    return render(request, 'ecom/my_profile.html', {
        'customer': customer,
        'user': request.user  # Pass the user object to the template
    })


from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required, user_passes_test
from . import forms, models

@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def edit_profile_view(request):
    try:
        # Fetch customer and user objects based on the logged-in user
        customer = models.Customer.objects.get(user_id=request.user.id)
        user = models.User.objects.get(id=customer.user_id)
    except (models.Customer.DoesNotExist, models.User.DoesNotExist):
        return redirect('error_page')  # Redirect to error page if not found

    # Initialize forms with existing data
    userForm = forms.CustomerEditProfileForm(instance=user)
    customerForm = forms.CustomerForm(instance=customer)

    if request.method == 'POST':
        # Reinitialize forms with POST data and files (for profile picture)
        userForm = forms.CustomerEditProfileForm(request.POST, instance=user)
        customerForm = forms.CustomerForm(request.POST, request.FILES, instance=customer)

        if userForm.is_valid() and customerForm.is_valid():
            # Save the user form (this will correctly save the username and other user fields)
            userForm.save()

            # Save the customer form (this will handle the profile fields and picture)
            customerForm.save()

            # Redirect to the profile page after successful update
            return HttpResponseRedirect('my-profile')

    # Prepare context for rendering
    mydict = {
        'userForm': userForm,
        'customerForm': customerForm,
        'user': user,
        'customer': customer,
        'mobile': customer.mobile,
        'address': customer.address,
    }

    return render(request, 'ecom/edit_profile.html', context=mydict)

@login_required
def change_password(request):
    user = request.user  # Get the currently logged-in user

    if request.method == 'POST':
        form = SetPasswordForm(user, request.POST)  # Bind the form to the current user
        if form.is_valid():
            form.save()  # This hashes and updates the password in the database
            messages.success(request, "Your password has been successfully updated.")
            return redirect('customerlogin')  # Redirect to login or another page
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = SetPasswordForm(user)

    return render(request, 'change_password.html', {'form': form})


def aboutus_view(request):
    return render(request,'ecom/aboutus.html')

# userprofile/views.py


@login_required(login_url='customerlogin')
def edit_profile_photo(request):
    customer = request.user.customer  # Access the Customer object linked to the logged-in user

    if request.method == 'POST':
        form = CustomerProfileForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            form.save()  # Save the updated profile picture or other details
            return redirect('my-profile')  # Redirect to the profile page after saving
    else:
        form = CustomerProfileForm(instance=customer)

    return render(request, 'ecom/edit_profile_photo.html', {'form': form, 'customer': customer})

