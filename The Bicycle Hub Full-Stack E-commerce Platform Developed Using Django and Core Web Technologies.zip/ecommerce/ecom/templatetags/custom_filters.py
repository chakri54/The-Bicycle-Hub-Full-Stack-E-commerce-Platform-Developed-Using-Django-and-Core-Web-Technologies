from django import template

register = template.Library()



@register.filter
def get_item(dictionary, key):
    """Custom filter to get value from dictionary."""
    return dictionary.get(str(key), 0)






    

@register.filter
def mul(value, arg):
    """Multiply the value by the argument."""
    try:
        return value * int(arg)
    except (ValueError, TypeError):
        return value

@register.filter
def get_quantity(product_quantities, product_id):
    """Returns the quantity of a product from the product_quantities dictionary"""
    try:
        return product_quantities.get(int(product_id), 0)
    except AttributeError:
        return 0  # Return 0 if product_quantities is not a dictionary



@register.filter(name='multiply')
def multiply(value, arg):
    """Multiplies the value by the argument."""
    try:
        return value * arg
    except (TypeError, ValueError):
        return value  