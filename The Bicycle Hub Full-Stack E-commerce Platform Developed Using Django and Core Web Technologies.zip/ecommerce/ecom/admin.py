from django.contrib import admin
from .models import Customer,Product,Orders
# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'price', 'product_image', 'description')  # Fields displayed in the list view
    search_fields = ('name', 'description')  # Fields for the search bar
    list_filter = ('price','id')  # Add filtering options (e.g., by price)
    ordering = ('-id',)  # Default ordering (e.g., by newest)
    readonly_fields = ('id',)  # Make the 'id' field read-only in the admin panel

admin.site.register(Product, ProductAdmin)


class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'product', 'status', 'order_date', 'email', 'address', 'mobile')  # Fields displayed in list view
    search_fields = ('customer__user__username', 'product__name', 'email', 'status')  # Enable search on specific fields
    list_filter = ('status', 'order_date')  # Add filtering options (e.g., by status or order date)
    ordering = ('-order_date',)  # Default ordering by the most recent order
    readonly_fields = ('order_date',)  

admin.site.register(Orders, OrderAdmin)


class CustomerAdmin(admin.ModelAdmin):
    list_display = ('user', 'first_name', 'last_name', 'mobile','address','profile_pic')  # Fields to display in the list view
    search_fields = ('first_name', 'last_name', 'mobile')  # Fields for the search bar

admin.site.register(Customer, CustomerAdmin)
